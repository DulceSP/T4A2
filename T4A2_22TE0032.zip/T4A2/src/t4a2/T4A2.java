package t4a2;

import java.util.Scanner;

/**
 *
 * @author Dulce Santos
 */
public class T4A2 {

    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        //ejercicio3();
        //ejercicio4();
    }

    public static void ejercicio1() {
        // Dise�a una aplicaci�n que muestre las tablas de multiplicar del 1 al 10 

        System.out.println("tablas de multiplicar");

        for (int i = 1; i < 11; i++) {
            for (int j = 1; j < 11; j++) {
                System.out.println(i + " x " + j + "=" + (i * j));
            }
        }
    }

    public static void ejercicio2() {
        // Realizar un programa en java que pida un n�mero x, y nos diga cu�ntos n�meros 
        //hay entre 1 y n que son primos
        Scanner scanner = new Scanner(System.in);

        System.out.println("Numeros primos");

        System.out.println("Ingresa el numero limite");
        int l = scanner.nextInt();

        for (int i = 1; i <= l; i++) {
            System.out.println(" " + i);

        }

    }

    public static void ejercicio3() {
        // Realizar un programa en java que pida un n�mero x, y nos 
        //diga cu�ntos n�meros hay entre 1 y n, cu�ntos pares y cu�ntos impares

        Scanner scanner = new Scanner(System.in);

        System.out.println("Numeros pares e impares");
        System.out.printf("Introduzca un n�mero entero: ");
        int ne = scanner.nextInt();

        for (int i = 1; i <= ne; i++) {
            System.out.println(" " + i);
            if (i % 2 == 0) {
                System.out.println("El n�mero es par");
            } else {
                System.out.println("El n�mero es impar");
            }
        }

    }

    public static void ejercicio4(String[] args) {
        // Dise�ar una aplicaci�n donde escribas una palabra y la imprima alreves

        String cadena = " ";
        if (args.length == 1) {
	  cadena = args[0];
      }
        
    }
    public static String InvertirCadena(String cadena) {
        String cadenaInvertida = "";
        for (int x = cadena.length() - 1; x >= 0; x--) {
            cadenaInvertida = cadenaInvertida + cadena.charAt(x);
        }
        return cadenaInvertida;
    }
}
